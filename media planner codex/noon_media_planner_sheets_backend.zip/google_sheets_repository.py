from __future__ import annotations

from collections import defaultdict
from datetime import date, datetime, timedelta
from uuid import uuid4

import google.auth
import gspread

from config import Settings
from models import MediaPlanRequest, PlanLine


RUN_HEADERS = [
    "plan_code",
    "created_at",
    "brand",
    "brand_tag",
    "comcats",
    "country",
    "start_date",
    "end_date",
    "budget",
    "currency",
    "objective",
    "allocated",
    "remaining",
    "estimated_views",
    "line_count",
    "plan_link",
]

LINE_HEADERS = [
    "plan_code",
    "line_id",
    "from",
    "to",
    "page",
    "asset",
    "days",
    "buy_type",
    "rate",
    "views",
    "cost",
    "phase",
    "brand",
    "stype",
    "slot_code",
    "score",
    "available_views",
    "historical_ctr",
    "historical_roas",
    "historical_cpm",
]


def norm(value) -> str:
    return str(value or "").strip().lower()


def parse_date(value) -> date | None:
    if isinstance(value, date):
        return value
    text = str(value or "").strip()
    if not text:
        return None
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%m/%d/%Y", "%d-%m-%Y", "%Y/%m/%d"):
        try:
            return datetime.strptime(text, fmt).date()
        except ValueError:
            pass
    try:
        return datetime.fromisoformat(text).date()
    except ValueError:
        return None


def parse_number(value) -> float:
    text = str(value or "").replace(",", "").strip()
    if text in {"", "-"}:
        return 0.0
    try:
        return float(text)
    except ValueError:
        return 0.0


class GoogleSheetsRepository:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.client = self._client()
        self.sheet = self.client.open_by_key(settings.google_sheet_id)

    def _client(self):
        try:
            scopes = [
                "https://www.googleapis.com/auth/spreadsheets",
                "https://www.googleapis.com/auth/drive",
            ]
            creds, _ = google.auth.default(scopes=scopes)
            return gspread.authorize(creds)
        except Exception:
            return gspread.service_account()

    def _worksheet(self, title: str):
        return self.sheet.worksheet(title)

    def _records(self, title: str) -> list[dict]:
        rows = self._worksheet(title).get_all_records()
        return [{str(k).strip(): v for k, v in row.items()} for row in rows]

    def _ensure_worksheet(self, title: str, headers: list[str]):
        try:
            ws = self.sheet.worksheet(title)
        except gspread.WorksheetNotFound:
            ws = self.sheet.add_worksheet(title=title, rows=1000, cols=len(headers))
            ws.append_row(headers)
            return ws

        existing = ws.row_values(1)
        if not existing:
            ws.append_row(headers)
        return ws

    def fetch_historical_performance(self, req: MediaPlanRequest) -> list[dict]:
        rows = self._records(self.settings.delivery_tab)
        start = req.start_date - timedelta(days=self.settings.historical_lookback_days)
        comcats = {norm(c) for c in req.comcats if norm(c)}
        country = norm(req.country)
        brand = norm(req.brand)

        def aggregate(source_rows: list[dict], brand_specific: bool) -> list[dict]:
            grouped: dict[tuple[str, str, str], dict] = {}
            active_dates: dict[tuple[str, str, str], set[date]] = defaultdict(set)
            for row in source_rows:
                key = (
                    str(row.get("slot_code") or "").strip(),
                    str(row.get("publisher") or "").strip(),
                    str(row.get("pricing_model") or "").strip(),
                )
                if not key[0]:
                    continue
                target = grouped.setdefault(
                    key,
                    {
                        "slot_code": key[0],
                        "publisher": key[1],
                        "pricing_model": key[2],
                        "views": 0,
                        "clicks": 0,
                        "revenue": 0.0,
                        "spends": 0.0,
                        "active_days": 0,
                        "brand_specific": brand_specific,
                    },
                )
                target["views"] += int(parse_number(row.get("views")))
                target["clicks"] += int(parse_number(row.get("clicks")))
                target["revenue"] += parse_number(row.get("revenue"))
                target["spends"] += parse_number(row.get("spends"))
                row_date = parse_date(row.get("date"))
                if row_date:
                    active_dates[key].add(row_date)
            for key, target in grouped.items():
                target["active_days"] = max(len(active_dates[key]), 1)
            return list(grouped.values())

        matched: list[dict] = []
        brand_rows: list[dict] = []
        for row in rows:
            row_date = parse_date(row.get("date"))
            if not row_date or row_date < start or row_date >= req.start_date:
                continue
            if norm(row.get("country")) != country:
                continue
            if norm(row.get("comcat")) not in comcats and norm(row.get("category")) not in comcats:
                continue
            matched.append(row)
            if norm(row.get("brand")) == brand:
                brand_rows.append(row)

        if req.brand_tag == "old" and brand_rows:
            return aggregate(brand_rows, brand_specific=True)
        return aggregate(matched, brand_specific=False)

    def fetch_inventory(self, req: MediaPlanRequest) -> list[dict]:
        forecast_rows = self._records(self.settings.forecast_tab)
        booking_rows = self._records(self.settings.booking_tab)
        country = norm(req.country)

        booked_by_date_slot: dict[tuple[date, str], int] = defaultdict(int)
        for row in booking_rows:
            dt = parse_date(row.get("dt"))
            if not dt or dt < req.start_date or dt > req.end_date:
                continue
            if norm(row.get("country")) != country:
                continue
            status = norm(row.get("campaign_status"))
            if status in {"cancelled", "canceled", "rejected"}:
                continue
            slot = str(row.get("slot_code") or "").strip()
            booked_by_date_slot[(dt, slot)] += int(parse_number(row.get("booked_views") or row.get("delivered_views")))

        inventory: list[dict] = []
        for row in forecast_rows:
            dt = parse_date(row.get("dt"))
            if not dt or dt < req.start_date or dt > req.end_date:
                continue
            if norm(row.get("country")) != country:
                continue
            slot = str(row.get("slot") or row.get("slot_code") or "").strip()
            forecast = int(parse_number(row.get("slot_sessions")))
            booked = booked_by_date_slot.get((dt, slot), 0)
            inventory.append(
                {
                    "dt": dt,
                    "slot_code": slot,
                    "forecast_views": forecast,
                    "booked_views": booked,
                    "available_views": max(forecast - booked, 0),
                }
            )
        return inventory

    def fetch_slot_names(self, req: MediaPlanRequest) -> dict[str, str]:
        names: dict[str, str] = {}
        for row in self._records(self.settings.booking_tab):
            slot = str(row.get("slot_code") or "").strip()
            slot_name = str(row.get("slot_name") or "").strip()
            if slot and slot_name:
                names.setdefault(slot, slot_name)
        return names

    def list_comcats(self) -> list[str]:
        values = set()
        for title, field in (
            (self.settings.delivery_tab, "comcat"),
            (self.settings.booking_tab, "comcat"),
        ):
            try:
                for row in self._records(title):
                    value = str(row.get(field) or "").strip()
                    if value:
                        values.add(value)
            except Exception:
                continue
        return sorted(values, key=str.lower)

    def save_plan(self, req: MediaPlanRequest, rows: list[PlanLine], summary: dict) -> tuple[str, str]:
        plan_code = f"MP-{datetime.utcnow().strftime('%Y%m%d-%H%M%S')}-{uuid4().hex[:6].upper()}"
        lines_ws = self._ensure_worksheet(self.settings.plan_lines_tab, LINE_HEADERS)
        runs_ws = self._ensure_worksheet(self.settings.plan_runs_tab, RUN_HEADERS)
        plan_link = f"https://docs.google.com/spreadsheets/d/{self.settings.google_sheet_id}/edit#gid={lines_ws.id}"

        runs_ws.append_row(
            [
                plan_code,
                datetime.utcnow().isoformat(timespec="seconds") + "Z",
                req.brand,
                req.brand_tag,
                ", ".join(req.comcats),
                req.country,
                req.start_date.isoformat(),
                req.end_date.isoformat(),
                req.budget,
                req.currency,
                req.objective,
                summary["allocated"],
                summary["remaining"],
                summary["estimated_views"],
                summary["line_count"],
                plan_link,
            ],
            value_input_option="USER_ENTERED",
        )

        if rows:
            lines_ws.append_rows(
                [
                    [
                        plan_code,
                        row.id,
                        row.from_date.isoformat(),
                        row.to_date.isoformat(),
                        row.page,
                        row.asset,
                        row.days,
                        row.buyType,
                        row.rate,
                        row.views or "",
                        row.cost,
                        row.phase,
                        row.brand,
                        row.stype,
                        row.slot_code,
                        row.score,
                        row.available_views,
                        row.historical_ctr or "",
                        row.historical_roas or "",
                        row.historical_cpm or "",
                    ]
                    for row in rows
                ],
                value_input_option="USER_ENTERED",
            )
        return plan_code, plan_link
