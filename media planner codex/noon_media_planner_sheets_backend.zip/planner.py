from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from datetime import date
from math import isfinite

from models import MediaPlanRequest, Phase, PlanLine


@dataclass(frozen=True)
class Candidate:
    slot_code: str
    slot_name: str | None
    publisher: str | None
    pricing_model: str
    views: int
    clicks: int
    revenue: float
    spends: float
    active_days: int
    brand_specific: bool
    reach_score: float
    conv_score: float
    cpm: float | None
    cpd: float | None
    ctr: float | None
    roas: float | None


def inclusive_days(start: date, end: date) -> int:
    return max((end - start).days + 1, 1)


def normalize_pricing_model(value: str | None) -> str:
    raw = (value or "").strip().lower()
    if raw in {"cpd", "cost per day", "cost_per_day", "day"}:
        return "CPD"
    return "CPM"


def page_from_slot(slot_code: str, publisher: str | None) -> str:
    text = f"{publisher or ''} {slot_code}".lower()
    if "clp" in text or "category" in text:
        return "CLP"
    if "pdp" in text:
        return "PDP"
    if "search" in text:
        return "Search"
    return publisher or "Home Page"


def asset_from_slot(slot_code: str, slot_name: str | None) -> str:
    return slot_name or slot_code.replace("_", " ").title()


def default_phases(req: MediaPlanRequest) -> list[Phase]:
    if req.phases:
        return req.phases
    return [Phase.model_validate({"name": "Full flight", "from": req.start_date, "to": req.end_date})]


def objective_weights(req: MediaPlanRequest) -> tuple[float, float]:
    if req.objective == "reach":
        return 1.0, 0.0
    if req.objective == "roas":
        return 0.0, 1.0
    reach = max(req.reach_weight, 0)
    roas = max(req.roas_weight, 0)
    total = reach + roas
    if total <= 0:
        return 0.6, 0.4
    return reach / total, roas / total


def build_candidates(
    historical_rows: list[dict],
    slot_names: dict[str, str],
    settings,
) -> list[Candidate]:
    candidates: list[Candidate] = []
    for row in historical_rows:
        views = int(row.get("views") or 0)
        clicks = int(row.get("clicks") or 0)
        spends = float(row.get("spends") or 0)
        revenue = float(row.get("revenue") or 0)
        active_days = int(row.get("active_days") or 1)
        if views < settings.min_slot_views and spends <= 0:
            continue

        cpm = spends * 1000 / views if views > 0 and spends > 0 else None
        ctr = clicks / views if views > 0 else None
        roas = revenue / spends if spends > 0 else None
        cpd = spends / active_days if active_days > 0 and spends > 0 else None

        safe_cpm = cpm if cpm and isfinite(cpm) and cpm > 0 else settings.default_cpm
        reach_score = views / safe_cpm
        conv_score = (roas or 0) * 100 + (ctr or 0) * 10000 + revenue / 1000
        if row.get("brand_specific"):
            reach_score *= 1.15
            conv_score *= 1.2

        slot_code = row["slot_code"]
        candidates.append(
            Candidate(
                slot_code=slot_code,
                slot_name=slot_names.get(slot_code),
                publisher=row.get("publisher"),
                pricing_model=normalize_pricing_model(row.get("pricing_model")),
                views=views,
                clicks=clicks,
                revenue=revenue,
                spends=spends,
                active_days=active_days,
                brand_specific=bool(row.get("brand_specific")),
                reach_score=reach_score,
                conv_score=conv_score,
                cpm=cpm,
                cpd=cpd,
                ctr=ctr,
                roas=roas,
            )
        )

    deduped: dict[tuple[str, str], Candidate] = {}
    for candidate in sorted(candidates, key=lambda c: (c.brand_specific, c.views), reverse=True):
        deduped.setdefault((candidate.slot_code, candidate.pricing_model), candidate)
    return list(deduped.values())


def plan_media(
    req: MediaPlanRequest,
    historical_rows: list[dict],
    inventory_rows: list[dict],
    slot_names: dict[str, str],
    settings,
) -> tuple[list[PlanLine], dict]:
    candidates = build_candidates(historical_rows, slot_names, settings)
    if not candidates:
        return [], {"reason": "No historical delivery rows found for this brand/comcat/country fallback set."}

    inventory_by_slot_phase: dict[tuple[str, str], int] = defaultdict(int)
    for row in inventory_rows:
        dt = row["dt"]
        slot = row["slot_code"]
        available = max(int(row.get("available_views") or 0), 0)
        for phase in default_phases(req):
            if phase.from_date <= dt <= phase.to_date:
                inventory_by_slot_phase[(slot, phase.name)] += available

    phases = default_phases(req)
    total_days = sum(inclusive_days(p.from_date, p.to_date) for p in phases)
    reach_weight, roas_weight = objective_weights(req)
    line_id = 1
    rows: list[PlanLine] = []
    spent = 0.0

    for phase in phases:
        phase_share = inclusive_days(phase.from_date, phase.to_date) / total_days
        for stype, weight, score_name in (
            ("reach", reach_weight, "reach_score"),
            ("conv", roas_weight, "conv_score"),
        ):
            target = req.budget * phase_share * weight
            if target <= 0:
                continue
            remaining_target = target
            ranked = sorted(candidates, key=lambda c: getattr(c, score_name), reverse=True)
            used_in_phase = 0
            for candidate in ranked:
                if used_in_phase >= settings.max_lines_per_phase or remaining_target <= 1:
                    break
                available = inventory_by_slot_phase.get((candidate.slot_code, phase.name), 0)
                if available <= 0:
                    continue

                buy_type = "Cost Per Day" if candidate.pricing_model == "CPD" else "CPM"
                days = inclusive_days(phase.from_date, phase.to_date)
                if buy_type == "CPM":
                    rate = round(candidate.cpm or settings.default_cpm, 2)
                    planned_views = int(min(available, remaining_target * 1000 / max(rate, 0.01)))
                    if planned_views < 1000:
                        continue
                    cost = round(planned_views * rate / 1000, 2)
                else:
                    rate = round(candidate.cpd or settings.default_cpd, 2)
                    max_days = min(days, max(int(remaining_target // max(rate, 0.01)), 1))
                    cost = round(rate * max_days, 2)
                    planned_views = min(available, int(candidate.views / max(candidate.active_days, 1) * max_days)) or None

                if spent + cost > req.budget * 1.03:
                    cost = max(req.budget - spent, 0)
                    if cost <= 1:
                        break
                    if buy_type == "CPM":
                        planned_views = int(cost * 1000 / max(rate, 0.01))

                rows.append(
                    PlanLine.model_validate(
                        {
                            "id": line_id,
                            "from": phase.from_date,
                            "to": phase.to_date,
                            "page": page_from_slot(candidate.slot_code, candidate.publisher),
                            "asset": asset_from_slot(candidate.slot_code, candidate.slot_name),
                            "days": days,
                            "buyType": buy_type,
                            "rate": rate,
                            "views": planned_views,
                            "cost": round(cost, 2),
                            "phase": phase.name,
                            "brand": req.brand,
                            "stype": stype,
                            "slot_code": candidate.slot_code,
                            "score": round(getattr(candidate, score_name), 4),
                            "available_views": available,
                            "historical_ctr": candidate.ctr,
                            "historical_roas": candidate.roas,
                            "historical_cpm": candidate.cpm,
                        }
                    )
                )
                line_id += 1
                spent += cost
                remaining_target -= cost
                inventory_by_slot_phase[(candidate.slot_code, phase.name)] -= int(planned_views or 0)
                used_in_phase += 1

    diagnostics = {
        "candidate_count": len(candidates),
        "historical_rows": len(historical_rows),
        "inventory_rows": len(inventory_rows),
        "allocated": round(sum(row.cost for row in rows), 2),
    }
    return rows, diagnostics
