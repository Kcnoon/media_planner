from datetime import date
from typing import Literal
from pydantic import BaseModel, Field


Objective = Literal["reach", "roas", "both"]
BrandTag = Literal["old", "new"]


class Phase(BaseModel):
    name: str
    from_date: date = Field(alias="from")
    to_date: date = Field(alias="to")


class MediaPlanRequest(BaseModel):
    brand: str
    brand_tag: BrandTag
    comcats: list[str] = Field(default_factory=list)
    country: str
    start_date: date
    end_date: date
    budget: float
    currency: str
    objective: Objective
    reach_weight: int = 60
    roas_weight: int = 40
    phases: list[Phase] = Field(default_factory=list)


class PlanLine(BaseModel):
    id: int
    from_date: date = Field(alias="from")
    to_date: date = Field(alias="to")
    page: str
    asset: str
    days: int
    buyType: str
    rate: float
    views: int | None
    cost: float
    phase: str
    brand: str
    stype: Literal["reach", "conv"]
    slot_code: str
    score: float
    available_views: int
    historical_ctr: float | None = None
    historical_roas: float | None = None
    historical_cpm: float | None = None


class MediaPlanResponse(BaseModel):
    rows: list[PlanLine]
    summary: dict
    diagnostics: dict
