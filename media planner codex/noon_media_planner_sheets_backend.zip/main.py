from datetime import date

from fastapi import Depends, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from config import Settings, get_settings
from google_sheets_repository import GoogleSheetsRepository
from models import MediaPlanRequest, MediaPlanResponse
from plan_store import PlanStore
from planner import plan_media


app = FastAPI(title="Noon Media Planner API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


def get_repo(settings: Settings = Depends(get_settings)) -> GoogleSheetsRepository:
    return GoogleSheetsRepository(settings)


def get_store() -> PlanStore:
    return PlanStore()


@app.get("/")
def index():
    return FileResponse("noon_media_planner.html")


@app.get("/api/health")
def health():
    return {"ok": True}


@app.get("/api/options")
def list_options(repo: GoogleSheetsRepository = Depends(get_repo)):
    return {"countries": ["ae", "sa", "eg"], "comcats": repo.list_comcats()}


@app.post("/api/media-plan", response_model=MediaPlanResponse)
def create_media_plan(
    req: MediaPlanRequest,
    settings: Settings = Depends(get_settings),
    repo: GoogleSheetsRepository = Depends(get_repo),
    store: PlanStore = Depends(get_store),
):
    if req.end_date < req.start_date:
        raise HTTPException(status_code=400, detail="end_date must be on or after start_date")
    if req.start_date < date.today():
        raise HTTPException(status_code=400, detail="start_date must be today or later")
    if req.budget <= 0:
        raise HTTPException(status_code=400, detail="budget must be positive")
    if not req.comcats:
        raise HTTPException(status_code=400, detail="select at least one comcat")
    if req.country.lower() not in {"ae", "sa", "eg"}:
        raise HTTPException(status_code=400, detail="country must be one of ae, sa, eg")

    historical_rows = repo.fetch_historical_performance(req)
    inventory_rows = repo.fetch_inventory(req)
    slot_names = repo.fetch_slot_names(req)
    rows, diagnostics = plan_media(req, historical_rows, inventory_rows, slot_names, settings)

    allocated = round(sum(row.cost for row in rows), 2)
    views = sum(row.views or 0 for row in rows)
    summary = {
        "brand": req.brand,
        "comcats": req.comcats,
        "country": req.country,
        "budget": req.budget,
        "allocated": allocated,
        "remaining": round(req.budget - allocated, 2),
        "estimated_views": views,
        "line_count": len(rows),
    }
    sheet_plan_code, sheet_plan_link = repo.save_plan(req, rows, summary)
    summary["sheet_plan_code"] = sheet_plan_code
    summary["sheet_plan_link"] = sheet_plan_link
    plan_id = store.save(req, rows, summary, diagnostics)
    summary["plan_id"] = plan_id
    return {"rows": rows, "summary": summary, "diagnostics": diagnostics}


@app.get("/api/media-plan/{plan_id}")
def get_media_plan(plan_id: str, store: PlanStore = Depends(get_store)):
    plan = store.get(plan_id)
    if not plan:
        raise HTTPException(status_code=404, detail="plan not found")
    return plan


app.mount("/static", StaticFiles(directory="."), name="static")
